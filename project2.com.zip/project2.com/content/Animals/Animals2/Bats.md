---
title: "Bats"
slug: bats
draft: false
---

##### Author: Caleb Williams  

![Handsome Bat](https://www.bluestemprairie.com/.a/6a00d834516a0869e2017c324a5b47970b-800wi "Bat Smiling for the camera")

Bats are mammals of the order Chiroptera; with their forelimbs adapted as wings, they are the only mammals naturally capable of true and sustained flight.


## Bat Behavior

There are many things about bats that make them unique, among them being:

1. Bats are the second largest order of mammals, comprising about 20% of all classified mammal species.

2. Bats are nocturnal (active at night).

3. Most bats feed on insects, while others eat fruit, fish or even blood!

4. Some bats live by themselves while others live in caves with thousands of other bats.

5. Vampire bats have small and extremely sharp teeth which are capable of piercing an animal’s skin (humans included) without them even noticing.

6. Bats can live for over 20 years.

![Handsome Bat](https://i.pinimg.com/originals/11/8c/5c/118c5c0ecef1b382c67af82e85571b4a.jpg "Bat Smiling for the camera")
