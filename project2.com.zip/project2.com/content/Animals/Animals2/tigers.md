---
title: Tigers
slug: "tigers"
draft: false
---

##### Author: Abdul Khan

The Tiger is the largest cat species, most recognizable for its pattern of dark vertical stripes on reddish-oranage fur.

![Tiger](https://media-cdn.tripadvisor.com/media/photo-s/01/0d/08/2d/tigger-disneyland.jpg)

### **Cool Tiger Facts:**

1. Life span in captivity is 16-18 years.

2. Average speed of an adult tiger is 30 - 40 pmh.

3. Mass size of an adult  male tiger is 200-670 lbs, while the mass size of an adult female is 140 - 370 lbs. 

4. The scientific name is Panthera Tigris.

5. There are 6 types of tigers: Bengal Tiger, Indochinese Tiger, Malayan Tiger, Siberian Tiger, Sumatran Tiger, South China Tiger.

6. The most endangered type of tiger is the South China Tiger, which is facing the near point of extinction.

7. Tigers are the largest cat species in the world and the third-largest carnivore on land--only polar and brown bears are larger.

![Tiger](http://www.undp.org/content/dam/undp/img/environmentandenergy/ecosystems_and_biodiversity/undp_in-Tiger-Midori-Paxton-2016.jpg)

