---
title: "Cats"
slug: cats
draft: false
---

##### Author: Nathan Taylor  

![scared cat](https://i.ytimg.com/vi/4ptZPi9e2Ko/maxresdefault.jpg "Cat Scared of Being Touched")

Cats are domesticated predators that went from dangerous hunters to wimpy and fat pets (by wimpy and fat I mean cool and suave). They are independent jerks that depend on us for their food (and we depend on them to defend us).



## Cat Behavior

Cats have some weird behaviors left over from them being actually good at hunting:

1. Cats give humans their dead mice because they see us as part of their group and want to share their kills.

2. Cats like squeezing into boxes and tight spaces because it makes them feel more secure. In the wild they would hide when trying to rest.

3. Cats will chew non food items to deal with stress or sickness.

4. Cats are carnivores but will eat grass or house plants to get fiber.

5. Cats have scent glands on their face, so when they rub their faces on things it marks it as their property and serves as an identifier for other cats.

6. Domestic cats spend about 70 percent of the day sleeping. And 15 percent of the day grooming.

7. A house cat can run faster than Usain Bolt. 

![Not very tasty](https://media.mnn.com/assets/images/2018/07/cat_eating_fancy_ice_cream.jpg.838x0_q80.jpg "He asked for chocolate")
