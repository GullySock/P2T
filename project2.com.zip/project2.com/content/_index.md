# Project 2
Everyone will make a page in `project2.com\content\Animals\Animals2` about their favorite animal and make changes to other members' pages. We also need to make some customizations to the sidebar and whatever else we feel like doing for fun.

#### Things eveyone will need:
* The GitHub app
* Hugo installed locally for testing


#### Useful links:
* Hugo Knowledgebase: https://gohugo.io/documentation/
* Detailed Theme Customization: https://learn.netlify.com/en/cont/pages/
* Markdown Cheat Sheet: https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet
